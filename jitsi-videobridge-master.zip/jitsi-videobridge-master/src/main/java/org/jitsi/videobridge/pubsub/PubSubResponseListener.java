/*
 * Copyright @ 2015 Atlassian Pty Ltd
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jitsi.videobridge.pubsub;

import org.jivesoftware.smack.packet.*;

/**
 * Interface for listener of PubSub responses.
 *
 * @author Hristo Terezov
 * @author Lyubomir Marinov
 */
public interface PubSubResponseListener
{
    /**
     * Enum for responses.
     */
    public static enum Response
    {
        SUCCESS,
        FAIL
    };

    /**
     * The method is called when response for node creation is received
     * @param response the type of the response.
     */
    public void onCreateNodeResponse(Response response);

    /**
     * The method is called when response for publish is received
     *
     * @param type the type of the response.
     * @param iq the response <tt>IQ</tt>
     */
    public void onPublishResponse(Response type, IQ iq);
}
